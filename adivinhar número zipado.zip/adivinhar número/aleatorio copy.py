import random

n = 1000
numero_aleatorio = random.randint(0, n)
tentativas = []
numero_de_vezes = 1000

for i in range(numero_de_vezes):
    executando = True
    tentativac = 0
    a = 0
    b = n+1
    while executando:
        tentativac += 1
        respostac = random.randint(a, b)
        if respostac > numero_aleatorio:
            if b > respostac:
                b = respostac
        elif respostac < numero_aleatorio:
            if a < respostac:
                a = respostac
        elif respostac == numero_aleatorio:
            executando =  False
    print(f"Número achado: {respostac} : {numero_aleatorio}!")
    tentativas.append(tentativac)


total = sum(tentativas)
media = total/numero_de_vezes
print(f"Média de tentativas para acertar o número: {media}")
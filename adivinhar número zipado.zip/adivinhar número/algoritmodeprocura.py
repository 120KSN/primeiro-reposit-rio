import random

n = 1000
numero_aleatorio = random.randint(0, n)
tentativas = []
numero_de_vezes = 1000

for i in range(n):
    executando = True
    respostac = n/2
    tentativac = 0
    while executando:
        tentativac += 1
        if respostac == numero_aleatorio:
            executando = False
        elif respostac > numero_aleatorio:
            respostac -= (respostac/2)
            respostac = int(respostac)
        else:
            respostac += (respostac/2)
            respostac = int(respostac)
        print(respostac)
    print(f"Número achado: {respostac} : {numero_aleatorio}!")
    tentativas.append(tentativac)


total = sum(tentativas)
media = total/numero_de_vezes
print(f"Média de tentativas para acertar o número: {media}")